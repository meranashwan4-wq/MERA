
from fastapi import FastAPI
from app.db.base import Base
from app.db.session import engine

from app.routers import student, major, subject, mark

Base.metadata.create_all(bind=engine)

app = FastAPI(title="School Management API")

app.include_router(student.router, prefix="/students", tags=["Students"])
app.include_router(major.router, prefix="/majors", tags=["Majors"])
app.include_router(subject.router, prefix="/subjects", tags=["Subjects"])
app.include_router(mark.router, prefix="/marks", tags=["Marks"])
