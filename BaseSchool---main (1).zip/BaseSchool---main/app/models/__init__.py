from app.models.subject import *
from app.models.marks import *
from app.models.major import *
from app.models.student import *


