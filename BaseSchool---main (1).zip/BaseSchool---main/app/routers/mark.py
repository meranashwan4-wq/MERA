
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.models.mark import Mark
from app.schemas.mark import MarkCreate, MarkResponse

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=MarkResponse)
def create_mark(mark: MarkCreate, db: Session = Depends(get_db)):
    db_mark = Mark(**mark.dict())
    db.add(db_mark)
    db.commit()
    db.refresh(db_mark)
    return db_mark

@router.get("/", response_model=list[MarkResponse])
def get_marks(db: Session = Depends(get_db)):
    return db.query(Mark).all()

@router.delete("/{mark_id}")
def delete_mark(mark_id: int, db: Session = Depends(get_db)):
    mark = db.query(Mark).get(mark_id)
    db.delete(mark)
    db.commit()
    return {"message": "Deleted"}
